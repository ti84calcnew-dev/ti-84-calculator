import { useState } from "react";

const NAV_LINKS = [
  { label: "Home", href: "#home" },
  { label: "Features", href: "#features" },
  { label: "Calculator", href: "#calculator" },
  { label: "How to Use", href: "#how-to-use" },
  { label: "FAQ", href: "#faq" },
];

const FEATURES = [
  {
    icon: "📈",
    title: "Graphing Functions",
    desc: "Plot multiple functions simultaneously, zoom in/out, trace curves, and analyze intersection points with full graphing capabilities.",
  },
  {
    icon: "🔢",
    title: "Scientific Calculations",
    desc: "Perform complex arithmetic, trigonometry, logarithms, exponents, and algebraic operations instantly.",
  },
  {
    icon: "📊",
    title: "Advanced Statistics",
    desc: "Compute mean, median, standard deviation, regression analysis, and create statistical plots with ease.",
  },
  {
    icon: "🧮",
    title: "Matrix Operations",
    desc: "Add, subtract, multiply matrices, find determinants, inverses, and solve systems of linear equations.",
  },
  {
    icon: "∫",
    title: "Calculus Tools",
    desc: "Evaluate derivatives, integrals, and limits. Visualize tangent lines and areas under curves.",
  },
  {
    icon: "💡",
    title: "No Download Required",
    desc: "100% browser-based. No installation needed — just open and start calculating on any device instantly.",
  },
];

const COMPARISON = [
  { feature: "Cost", online: "Free", physical: "~$100–$150" },
  { feature: "Graphing Functions", online: "✅ Yes", physical: "✅ Yes" },
  { feature: "Advanced Statistics", online: "✅ Yes", physical: "✅ Yes" },
  { feature: "Access", online: "Any Browser", physical: "Handheld Only" },
  { feature: "Exam Approval (SAT/ACT)", online: "❌ Not Allowed", physical: "✅ Allowed" },
  { feature: "Programming (TI-Basic)", online: "❌ Not Supported", physical: "✅ Supported" },
  { feature: "Battery / Charging", online: "✅ Not Required", physical: "Rechargeable Battery" },
  { feature: "Updates", online: "✅ Always Latest", physical: "Manual Updates" },
];

const STEPS = [
  {
    num: "01",
    title: "Open the Calculator",
    desc: "No downloads or installations are required. Simply visit our website and the TI-84 calculator is ready to use instantly in your browser.",
  },
  {
    num: "02",
    title: "Select Your Function",
    desc: "From basic arithmetic to solving equations, graphing functions, and working with matrices — everything is just a few clicks away.",
  },
  {
    num: "03",
    title: "Enter Your Values",
    desc: "Use the on-screen keypad or your keyboard to input numbers, variables, and expressions just like on a real TI-84.",
  },
  {
    num: "04",
    title: "Get Instant Results",
    desc: "Hit Enter or click your selection and see the result immediately — graphs, calculations, and statistics in real time.",
  },
];

const FAQS = [
  {
    q: "Is the TI-84 Online Calculator really free?",
    a: "Yes! Our TI-84 online calculator is completely free to use with no hidden fees, no sign-up required, and no download needed.",
  },
  {
    q: "Can I use it on my phone or tablet?",
    a: "Absolutely. The calculator is fully responsive and works on smartphones, tablets, laptops, and desktop computers in any modern browser.",
  },
  {
    q: "Is it allowed on the SAT or ACT?",
    a: "No. Online calculators are not permitted on standardized exams like the SAT or ACT. You need a physical TI-84 Plus CE for those tests.",
  },
  {
    q: "Does it support graphing?",
    a: "Yes! You can graph multiple functions, zoom in and out, trace curves, find intersections, and view tables of values.",
  },
  {
    q: "Who is this calculator best for?",
    a: "It's ideal for high school and college students, teachers, tutors, and professionals who need quick access to a powerful graphing calculator.",
  },
  {
    q: "Do I need to create an account?",
    a: "No account or registration is needed. Open the page and start calculating right away — it's that simple.",
  },
];

// --- Mini Calculator Logic ---
type CalcState = {
  display: string;
  expression: string;
  justEvaluated: boolean;
};

function evalExpression(expr: string): string {
  try {
    // Replace display symbols with JS operators
    let e = expr
      .replace(/×/g, "*")
      .replace(/÷/g, "/")
      .replace(/π/g, String(Math.PI))
      .replace(/√\(([^)]+)\)/g, (_: string, n: string) => String(Math.sqrt(Number(n))))
      .replace(/²/g, "**2");
    // eslint-disable-next-line no-new-func
    const result = Function('"use strict"; return (' + e + ")")();
    if (!isFinite(result)) return "Error";
    const num = parseFloat(result.toFixed(10));
    return String(num);
  } catch {
    return "Error";
  }
}

function TI84Calculator() {
  const [calc, setCalc] = useState<CalcState>({
    display: "0",
    expression: "",
    justEvaluated: false,
  });
  const [graphMode, setGraphMode] = useState(false);
  const [graphFn, setGraphFn] = useState("sin(x)");
  const [graphInput, setGraphInput] = useState("sin(x)");

  const handleButton = (val: string) => {
    setCalc((prev) => {
      let { display, expression, justEvaluated } = prev;

      if (val === "AC") {
        return { display: "0", expression: "", justEvaluated: false };
      }
      if (val === "DEL") {
        if (expression.length <= 1) return { display: "0", expression: "", justEvaluated: false };
        const newExpr = expression.slice(0, -1);
        return { display: newExpr, expression: newExpr, justEvaluated: false };
      }
      if (val === "=") {
        const result = evalExpression(expression || display);
        return { display: result, expression: result, justEvaluated: true };
      }
      if (val === "+/-") {
        if (display.startsWith("-")) {
          const nd = display.slice(1);
          return { display: nd, expression: nd, justEvaluated: false };
        }
        const nd = "-" + display;
        return { display: nd, expression: nd, justEvaluated: false };
      }
      if (val === "%") {
        const result = evalExpression("(" + expression + ")/100");
        return { display: result, expression: result, justEvaluated: true };
      }

      const isOperator = ["+", "-", "×", "÷"].includes(val);

      if (justEvaluated && !isOperator) {
        return { display: val, expression: val, justEvaluated: false };
      }

      const newExpr = (expression === "0" && !isOperator ? "" : expression) + val;
      return { display: newExpr, expression: newExpr, justEvaluated: false };
    });
  };

  const buttons = [
    ["2ND", "MODE", "DEL", "AC"],
    ["MATH", "APPS", "PRGM", "VARS"],
    ["X,T,θ,n", "STAT", "LINK", "LIST"],
    ["7", "8", "9", "÷"],
    ["4", "5", "6", "×"],
    ["1", "2", "3", "-"],
    ["0", ".", "π", "+"],
    ["+/-", "%", "GRAPH", "="],
  ];

  const getButtonStyle = (label: string) => {
    const base =
      "rounded-lg font-bold text-xs sm:text-sm select-none cursor-pointer transition-all duration-100 active:scale-95 shadow-md flex items-center justify-center h-10 sm:h-11";
    if (label === "=")
      return `${base} bg-gradient-to-b from-blue-500 to-blue-700 text-white border border-blue-800 shadow-blue-900`;
    if (["÷", "×", "-", "+"].includes(label))
      return `${base} bg-gradient-to-b from-orange-400 to-orange-600 text-white border border-orange-700 shadow-orange-900`;
    if (["AC", "DEL"].includes(label))
      return `${base} bg-gradient-to-b from-red-500 to-red-700 text-white border border-red-800`;
    if (["GRAPH"].includes(label))
      return `${base} bg-gradient-to-b from-green-500 to-green-700 text-white border border-green-800`;
    if (["2ND", "MODE", "MATH", "APPS", "PRGM", "VARS", "X,T,θ,n", "STAT", "LINK", "LIST"].includes(label))
      return `${base} bg-gradient-to-b from-slate-600 to-slate-800 text-slate-200 border border-slate-900 text-[10px]`;
    if (["π", "%", "+/-"].includes(label))
      return `${base} bg-gradient-to-b from-purple-500 to-purple-700 text-white border border-purple-800`;
    return `${base} bg-gradient-to-b from-slate-200 to-slate-400 text-slate-900 border border-slate-500`;
  };

  return (
    <div className="flex flex-col items-center">
      {/* Calculator Body */}
      <div className="w-full max-w-xs sm:max-w-sm rounded-3xl shadow-2xl overflow-hidden border-4 border-slate-800"
        style={{ background: "linear-gradient(160deg, #1e293b 0%, #0f172a 100%)" }}>
        {/* Top brand strip */}
        <div className="flex items-center justify-between px-4 pt-4 pb-1">
          <span className="text-blue-400 font-black text-lg tracking-widest">TEXAS INSTRUMENTS</span>
        </div>
        <div className="px-4 pb-1">
          <span className="text-white font-extrabold text-base tracking-wider">TI-84 Plus CE</span>
        </div>

        {/* Screen */}
        <div className="mx-4 my-2 rounded-xl overflow-hidden border-4 border-slate-700 shadow-inner"
          style={{ background: "#b8c8a0", minHeight: 110 }}>
          {graphMode ? (
            <div className="p-2">
              <div className="text-slate-700 text-xs font-mono mb-1">Y1={graphFn}</div>
              <GraphDisplay fn={graphFn} />
            </div>
          ) : (
            <div className="flex flex-col justify-between p-3 h-full min-h-[110px]">
              <div className="text-slate-600 text-xs font-mono">{calc.expression !== calc.display ? calc.expression : ""}</div>
              <div className="text-right font-mono text-2xl font-bold text-slate-800 break-all">
                {calc.display}
              </div>
            </div>
          )}
        </div>

        {/* Graph mode toggle */}
        {graphMode && (
          <div className="mx-4 mb-2 flex gap-2 items-center">
            <input
              className="flex-1 rounded bg-slate-700 text-white text-xs px-2 py-1 font-mono border border-slate-600"
              value={graphInput}
              onChange={(e) => setGraphInput(e.target.value)}
              placeholder="e.g. sin(x)"
            />
            <button
              className="bg-green-600 text-white text-xs px-3 py-1 rounded font-bold"
              onClick={() => setGraphFn(graphInput)}
            >PLOT</button>
          </div>
        )}

        {/* Buttons */}
        <div className="px-3 pb-4 grid grid-cols-4 gap-2">
          {buttons.flat().map((btn, i) => (
            <button
              key={i}
              className={getButtonStyle(btn)}
              onClick={() => {
                if (btn === "GRAPH") {
                  setGraphMode((g) => !g);
                } else if (!["2ND","MODE","MATH","APPS","PRGM","VARS","X,T,θ,n","STAT","LINK","LIST"].includes(btn)) {
                  if (graphMode) setGraphMode(false);
                  handleButton(btn);
                }
              }}
            >
              {btn}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// Simple SVG graph plotter
function GraphDisplay({ fn }: { fn: string }) {
  const W = 240, H = 80;
  const points: { x: number; y: number }[] = [];
  for (let px = 0; px <= W; px += 2) {
    const x = (px / W) * 4 * Math.PI - 2 * Math.PI;
    let y: number;
    try {
      // eslint-disable-next-line no-new-func
      y = Function("x", `"use strict"; with(Math){return ${fn.replace(/(\d)(x)/g,"$1*$2")}}`)(x);
    } catch {
      y = 0;
    }
    if (!isFinite(y)) continue;
    const py = H / 2 - (y * H) / 6;
    points.push({ x: px, y: py });
  }
  const d = points.map((p, i) => `${i === 0 ? "M" : "L"}${p.x},${Math.max(0, Math.min(H, p.y))}`).join(" ");

  return (
    <svg width={W} height={H} className="w-full" viewBox={`0 0 ${W} ${H}`}>
      {/* Axes */}
      <line x1={0} y1={H / 2} x2={W} y2={H / 2} stroke="#6b7280" strokeWidth={0.7} strokeDasharray="4,3" />
      <line x1={W / 2} y1={0} x2={W / 2} y2={H} stroke="#6b7280" strokeWidth={0.7} strokeDasharray="4,3" />
      {/* Curve */}
      <path d={d} fill="none" stroke="#1d4ed8" strokeWidth={2} />
    </svg>
  );
}

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border border-slate-200 rounded-xl overflow-hidden">
      <button
        className="w-full flex items-center justify-between px-6 py-4 text-left bg-white hover:bg-slate-50 transition-colors"
        onClick={() => setOpen((v) => !v)}
      >
        <span className="font-semibold text-slate-800 text-sm sm:text-base">{q}</span>
        <span className={`ml-4 text-blue-600 text-xl font-bold transition-transform duration-200 ${open ? "rotate-45" : ""}`}>+</span>
      </button>
      {open && (
        <div className="px-6 pb-4 pt-1 bg-slate-50 text-slate-600 text-sm leading-relaxed border-t border-slate-100">
          {a}
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white font-[Inter,sans-serif]">
      {/* ===== NAVBAR ===== */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <a href="#home" className="flex items-center gap-2 group">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center shadow-md">
                <span className="text-white text-base font-black">TI</span>
              </div>
              <span className="font-extrabold text-slate-900 text-lg tracking-tight hidden sm:block">
                TI-84 <span className="text-blue-600">Calculator</span>
              </span>
            </a>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-1">
              {NAV_LINKS.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="px-4 py-2 rounded-lg text-sm font-medium text-slate-600 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </div>

            {/* CTA */}
            <a
              href="#calculator"
              className="hidden md:inline-flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-sm font-semibold px-5 py-2.5 rounded-xl shadow-md hover:from-blue-700 hover:to-indigo-700 transition-all"
            >
              Use Calculator Free →
            </a>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100"
              onClick={() => setMobileMenuOpen((v) => !v)}
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {mobileMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-slate-100 bg-white px-4 pb-4 pt-2 space-y-1">
            {NAV_LINKS.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="block px-4 py-2 rounded-lg text-sm font-medium text-slate-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                {link.label}
              </a>
            ))}
            <a
              href="#calculator"
              onClick={() => setMobileMenuOpen(false)}
              className="block mt-2 text-center bg-blue-600 text-white text-sm font-semibold px-5 py-2.5 rounded-xl"
            >
              Use Calculator Free →
            </a>
          </div>
        )}
      </nav>

      {/* ===== HERO ===== */}
      <section id="home" className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-900 text-white pt-20 pb-28">
        {/* BG decoration */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-blue-500/10 blur-3xl" />
          <div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full bg-indigo-500/10 blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-blue-600/5 blur-3xl" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left copy */}
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 bg-blue-500/20 border border-blue-400/30 rounded-full px-4 py-1.5 text-blue-300 text-sm font-medium">
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse inline-block" />
                100% Free · No Download Required
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black leading-tight">
                The Best Free<br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">TI-84 Calculator</span><br />
                Online
              </h1>
              <p className="text-slate-300 text-lg leading-relaxed max-w-lg">
                Graph functions, solve equations, and perform advanced statistics — all powered by a full TI-84 Plus CE simulator.
                Works on any device, right in your browser.
              </p>
              <div className="flex flex-wrap gap-4">
                <a
                  href="#calculator"
                  className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white font-bold px-7 py-3.5 rounded-2xl shadow-xl hover:from-blue-600 hover:to-indigo-600 transition-all text-base"
                >
                  🚀 Launch Calculator
                </a>
                <a
                  href="#features"
                  className="inline-flex items-center gap-2 border border-slate-500 text-slate-300 font-semibold px-7 py-3.5 rounded-2xl hover:border-blue-400 hover:text-blue-300 transition-all text-base"
                >
                  Explore Features
                </a>
              </div>

              {/* Trust badges */}
              <div className="flex flex-wrap gap-6 pt-2 text-slate-400 text-sm">
                <span className="flex items-center gap-2"><span className="text-green-400">✓</span> Free Forever</span>
                <span className="flex items-center gap-2"><span className="text-green-400">✓</span> No Sign-up</span>
                <span className="flex items-center gap-2"><span className="text-green-400">✓</span> Works on Mobile</span>
                <span className="flex items-center gap-2"><span className="text-green-400">✓</span> Graphing Ready</span>
              </div>
            </div>

            {/* Right: Calculator */}
            <div className="flex justify-center lg:justify-end">
              <div className="relative">
                <div className="absolute inset-0 bg-blue-500/20 blur-3xl rounded-full scale-75" />
                <div className="relative z-10">
                  <TI84Calculator />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== STATS BAR ===== */}
      <section className="bg-blue-600 text-white py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              { num: "5M+", label: "Students Helped" },
              { num: "100%", label: "Free to Use" },
              { num: "0", label: "Downloads Needed" },
              { num: "24/7", label: "Always Available" },
            ].map((s) => (
              <div key={s.label}>
                <div className="text-3xl font-black">{s.num}</div>
                <div className="text-blue-200 text-sm mt-1">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== FEATURES ===== */}
      <section id="features" className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="text-blue-600 font-semibold text-sm uppercase tracking-wider">Why Choose Us</span>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mt-2 mb-4">
              Powerful Features for Every Student
            </h2>
            <p className="text-slate-500 max-w-2xl mx-auto text-base">
              Our free online TI-84 calculator packs all the features you need — from graphing to statistics —
              accessible from any device, any time.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map((f) => (
              <div
                key={f.title}
                className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-md hover:border-blue-200 transition-all group"
              >
                <div className="text-4xl mb-4">{f.icon}</div>
                <h3 className="text-lg font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">
                  {f.title}
                </h3>
                <p className="text-slate-500 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== CALCULATOR SECTION ===== */}
      <section id="calculator" className="py-20 bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-blue-400 font-semibold text-sm uppercase tracking-wider">Try It Now</span>
            <h2 className="text-3xl sm:text-4xl font-black text-white mt-2 mb-4">
              TI-84 Calculator — Live Demo
            </h2>
            <p className="text-slate-400 max-w-xl mx-auto text-base">
              Use the interactive calculator below. Press <strong className="text-white">GRAPH</strong> to switch to graphing mode and enter any function like{" "}
              <code className="bg-slate-700 px-2 py-0.5 rounded text-blue-300 text-sm">sin(x)</code>,{" "}
              <code className="bg-slate-700 px-2 py-0.5 rounded text-blue-300 text-sm">x**2</code>, or{" "}
              <code className="bg-slate-700 px-2 py-0.5 rounded text-blue-300 text-sm">cos(x)*2</code>.
            </p>
          </div>

          <div className="flex flex-col lg:flex-row items-center gap-12 justify-center">
            <TI84Calculator />

            <div className="text-slate-300 space-y-5 max-w-md">
              <h3 className="text-white text-xl font-bold">Quick Tips</h3>
              {[
                { icon: "🔢", tip: "Type numbers and operators using the keypad buttons." },
                { icon: "📈", tip: "Press GRAPH to enter graphing mode. Type a function and press PLOT." },
                { icon: "🧮", tip: "Use % to compute percentages and π for Pi calculations." },
                { icon: "❌", tip: "Press AC to clear all, or DEL to delete the last character." },
                { icon: "✅", tip: "Press = to evaluate your expression instantly." },
              ].map((t) => (
                <div key={t.tip} className="flex items-start gap-3 bg-white/5 rounded-xl p-4 border border-white/10">
                  <span className="text-2xl flex-shrink-0">{t.icon}</span>
                  <p className="text-sm leading-relaxed">{t.tip}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ===== HOW TO USE ===== */}
      <section id="how-to-use" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="text-blue-600 font-semibold text-sm uppercase tracking-wider">Simple Steps</span>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mt-2 mb-4">
              How to Use the TI-84 Online Calculator
            </h2>
            <p className="text-slate-500 max-w-2xl mx-auto">
              Getting started is incredibly simple. No setup, no login — just open and calculate.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {STEPS.map((step) => (
              <div key={step.num} className="relative">
                <div className="text-6xl font-black text-blue-100 mb-3">{step.num}</div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">{step.title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">{step.desc}</p>
                <div className="absolute top-4 left-14 w-px h-6 bg-blue-200 hidden lg:block" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== WHO IT'S FOR ===== */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-black mb-4">Who Can Benefit Most?</h2>
            <p className="text-blue-200 max-w-xl mx-auto">
              Our TI-84 online calculator is built for anyone who needs powerful math tools without the cost.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: "🎓", title: "High School Students", desc: "Algebra, geometry, trig — ace every class." },
              { icon: "🏫", title: "College Students", desc: "Calculus, stats, linear algebra made easy." },
              { icon: "👩‍🏫", title: "Teachers & Tutors", desc: "Demonstrate concepts live in class." },
              { icon: "💼", title: "Professionals", desc: "Quick scientific calculations on the go." },
            ].map((c) => (
              <div
                key={c.title}
                className="bg-white/10 border border-white/20 rounded-2xl p-6 text-center hover:bg-white/20 transition-all"
              >
                <div className="text-5xl mb-4">{c.icon}</div>
                <h3 className="font-bold text-lg mb-2">{c.title}</h3>
                <p className="text-blue-200 text-sm">{c.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== COMPARISON TABLE ===== */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="text-blue-600 font-semibold text-sm uppercase tracking-wider">Compare</span>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mt-2 mb-4">
              Online TI-84 vs. Physical TI-84 Plus CE
            </h2>
            <p className="text-slate-500 max-w-xl mx-auto">
              See how our free online version compares to the physical calculator.
            </p>
          </div>

          <div className="overflow-x-auto rounded-2xl shadow-lg border border-slate-200">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
                  <th className="text-left px-6 py-4 font-bold">Feature</th>
                  <th className="text-center px-6 py-4 font-bold">Online TI-84 (Free)</th>
                  <th className="text-center px-6 py-4 font-bold">Physical TI-84 Plus CE</th>
                </tr>
              </thead>
              <tbody>
                {COMPARISON.map((row, i) => (
                  <tr
                    key={row.feature}
                    className={`border-t border-slate-200 ${i % 2 === 0 ? "bg-white" : "bg-slate-50"} hover:bg-blue-50 transition-colors`}
                  >
                    <td className="px-6 py-4 font-semibold text-slate-700">{row.feature}</td>
                    <td className="px-6 py-4 text-center text-slate-600">{row.online}</td>
                    <td className="px-6 py-4 text-center text-slate-600">{row.physical}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* ===== FAQ ===== */}
      <section id="faq" className="py-20 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <span className="text-blue-600 font-semibold text-sm uppercase tracking-wider">Got Questions?</span>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mt-2 mb-4">
              Frequently Asked Questions
            </h2>
          </div>
          <div className="space-y-3">
            {FAQS.map((faq) => (
              <FAQItem key={faq.q} q={faq.q} a={faq.a} />
            ))}
          </div>
        </div>
      </section>

      {/* ===== CTA BANNER ===== */}
      <section className="py-20 bg-gradient-to-br from-slate-900 to-blue-950 text-white text-center">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-5xl mb-6">🧮</div>
          <h2 className="text-3xl sm:text-4xl font-black mb-4">
            Ready to Start Calculating?
          </h2>
          <p className="text-slate-300 text-lg mb-8 max-w-xl mx-auto">
            Join millions of students and teachers who use our free TI-84 online calculator every day.
            No signup, no cost, no limits.
          </p>
          <a
            href="#calculator"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-500 to-indigo-500 text-white font-bold px-10 py-4 rounded-2xl shadow-2xl hover:from-blue-600 hover:to-indigo-600 transition-all text-lg"
          >
            🚀 Launch Free Calculator
          </a>
        </div>
      </section>

      {/* ===== FOOTER ===== */}
      <footer className="bg-slate-900 text-slate-400 py-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-10">
            {/* Brand */}
            <div className="md:col-span-2 space-y-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center">
                  <span className="text-white text-base font-black">TI</span>
                </div>
                <span className="font-extrabold text-white text-lg">
                  TI-84 <span className="text-blue-400">Calculator</span>
                </span>
              </div>
              <p className="text-sm leading-relaxed max-w-xs">
                The best free online TI-84 graphing calculator. Built for students, teachers, and professionals worldwide.
              </p>
              <p className="text-xs text-slate-600">
                * This website is not affiliated with Texas Instruments. TI-84 is a trademark of Texas Instruments Inc.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-bold text-white mb-4 text-sm uppercase tracking-wider">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                {NAV_LINKS.map((link) => (
                  <li key={link.label}>
                    <a href={link.href} className="hover:text-blue-400 transition-colors">{link.label}</a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Resources */}
            <div>
              <h4 className="font-bold text-white mb-4 text-sm uppercase tracking-wider">Resources</h4>
              <ul className="space-y-2 text-sm">
                {["Graphing Guide", "Statistics Tutorial", "Algebra Tips", "Calculus Help", "SAT Math Prep"].map((r) => (
                  <li key={r}>
                    <a href="#" className="hover:text-blue-400 transition-colors">{r}</a>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm">
            <p>© {new Date().getFullYear()} TI-84 Calculator Online. All rights reserved.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-blue-400 transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-blue-400 transition-colors">Terms of Use</a>
              <a href="#" className="hover:text-blue-400 transition-colors">Contact</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
